plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jivan.lbwatchlist"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jivan.lbwatchlist"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }

    // Clave fija para que cada nueva versión se instale encima de la anterior
    signingConfigs {
        create("propia") {
            storeFile = file("lbwatchlist.jks")
            storePassword = "lbwatchlist"
            keyAlias = "lbw"
            keyPassword = "lbwatchlist"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("propia")
        }
        release {
            signingConfig = signingConfigs.getByName("propia")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sin dependencias externas: solo Android y Kotlin.
