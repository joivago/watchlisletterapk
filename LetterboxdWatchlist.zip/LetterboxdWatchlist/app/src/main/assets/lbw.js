/*
 * Funciones que la app inyecta en las páginas de Letterboxd.
 * No uso la API (es privada): leo la página y pulso el botón como lo harías tú.
 * Si Letterboxd cambia su diseño, este es el único archivo que habría que retocar.
 */
(function () {
  if (window.__lbw) return;

  function visible(el) {
    if (!el || !el.getClientRects().length) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0;
  }

  // Devuelve "/film/slug/" a partir de un enlace, o null.
  function filmPath(href) {
    if (!href) return null;
    var m = href.match(/^(?:https?:\/\/(?:www\.)?letterboxd\.com)?(\/film\/[^\/?#]+\/)/);
    return m ? m[1] : null;
  }

  function clean(t) { return (t || '').replace(/\s+/g, ' ').trim(); }

  // ---------- Página de búsqueda ----------
  function pickResult(year) {
    var cands = [];
    function add(path, text) {
      if (path && !cands.some(function (c) { return c.path === path; })) {
        cands.push({ path: path, text: clean(text) });
      }
    }
    var items = document.querySelectorAll('ul.results > li, .results li, .search-result, li.film-detail');
    items.forEach(function (li) {
      var a = li.querySelector('a[href*="/film/"]');
      var p = a ? filmPath(a.getAttribute('href')) : null;
      if (!p) {
        var d = li.querySelector('[data-target-link],[data-item-link],[data-film-link]');
        if (d) p = filmPath(d.getAttribute('data-target-link') || d.getAttribute('data-item-link') || d.getAttribute('data-film-link'));
      }
      add(p, li.textContent);
    });
    if (!cands.length) {
      // Plan B: cualquier enlace a una película dentro del contenido principal.
      var root = document.querySelector('#content, main, .content-wrap') || document.body;
      root.querySelectorAll('a[href*="/film/"]').forEach(function (a) {
        add(filmPath(a.getAttribute('href')), (a.closest('li') || a).textContent);
      });
    }
    if (!cands.length) return '';
    if (year) {
      for (var i = 0; i < cands.length; i++) {
        if (cands[i].text.indexOf(year) >= 0) return cands[i].path;
      }
    }
    return cands[0].path;
  }

  // ---------- Página de la película ----------
  function signature(el) {
    var cls = typeof el.className === 'string' ? el.className : (el.className && el.className.baseVal) || '';
    return [cls, el.getAttribute('href'), el.getAttribute('data-action'), el.getAttribute('title'),
      el.getAttribute('aria-label'), el.getAttribute('data-original-title'),
      clean(el.textContent).slice(0, 60)].join(' ').toLowerCase();
  }

  function findWatchlistControls() {
    // Primero busco en el panel de acciones de la película, para no tocar
    // los pósters de "películas similares", que también tienen su botón.
    var scopes = ['#userpanel', '.actions-panel', '.film-actions', '[class*="actions-panel"]',
      '[class*="userpanel"]', 'aside', '.sidebar'];
    var root = null;
    for (var i = 0; i < scopes.length; i++) {
      var r = document.querySelector(scopes[i]);
      if (r && /watchlist/i.test(r.innerHTML)) { root = r; break; }
    }
    root = root || document.body;

    var addEls = [], removeEls = [];
    root.querySelectorAll('a,button,span,li,label,div,[role="button"],[data-action]').forEach(function (el) {
      var s = signature(el);
      if (s.indexOf('watchlist') < 0) return;
      var href = el.getAttribute('href') || '';
      if (/^\/[^\/]+\/watchlist\/?$/.test(href)) return;          // enlace a tu perfil, no es el botón
      if (el.querySelectorAll('*').length > 15) return;             // contenedor demasiado grande
      if (/remove[\s-]*from[\s-]*watchlist|remove-watchlist|in[\s-]your[\s-]watchlist|on[\s-]your[\s-]watchlist|watchlisted|(^|\s)-on(\s|$)|is-on|(^|\s)-active(\s|$)/.test(s)) {
        removeEls.push(el);
      } else if (/add[\s-]*to[\s-]*watchlist|add-watchlist|\bwatchlist\b/.test(s)) {
        addEls.push(el);
      }
    });
    return { add: addEls.filter(visible), remove: removeEls.filter(visible) };
  }

  // "on" = ya está en la watchlist, "off" = no está, "unknown" = no encuentro el botón
  function state() {
    var f = findWatchlistControls();
    if (f.remove.length) return 'on';
    if (f.add.length) return 'off';
    return 'unknown';
  }

  function clickAdd() {
    var f = findWatchlistControls();
    if (!f.add.length) return 'none';
    var best = null;
    for (var i = 0; i < f.add.length && !best; i++) {
      var s = signature(f.add[i]);
      if (/add-to-watchlist/.test(s)) best = f.add[i];
    }
    for (var j = 0; j < f.add.length && !best; j++) {
      if (f.add[j].matches('a,button,[role="button"],[data-action]')) best = f.add[j];
    }
    best = best || f.add[0];
    try { best.scrollIntoView({ block: 'center' }); } catch (e) { /* no es imprescindible */ }
    best.click();
    return 'clicked';
  }

  function filmTitle() {
    var h = document.querySelector('h1.headline-1, h1.filmtitle, .film-header h1, h1');
    return clean(h ? h.textContent : document.title);
  }

  window.__lbw = { pickResult: pickResult, state: state, clickAdd: clickAdd, filmTitle: filmTitle };
})();
