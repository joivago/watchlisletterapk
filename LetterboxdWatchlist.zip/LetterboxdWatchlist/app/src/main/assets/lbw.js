/*
 * Funciones que la app inyecta en las páginas de Letterboxd.
 * No uso la API (es privada): leo la página y pulso el botón como lo harías tú.
 * Si Letterboxd cambia su diseño, este es el único archivo que habría que retocar.
 */
(function () {
  if (window.__lbw) return;

  function visible(el) {
    if (!el || !el.getClientRects().length) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0;
  }

  // Devuelve "/film/slug/" a partir de un enlace, o null.
  function filmPath(href) {
    if (!href) return null;
    var m = href.match(/^(?:https?:\/\/(?:www\.)?letterboxd\.com)?(\/film\/[^\/?#]+\/)/);
    return m ? m[1] : null;
  }

  function clean(t) { return (t || '').replace(/\s+/g, ' ').trim(); }

  // ---------- Página de búsqueda ----------
  function pickResult(year) {
    var cands = [];
    function add(path, text) {
      if (path && !cands.some(function (c) { return c.path === path; })) {
        cands.push({ path: path, text: clean(text) });
      }
    }
    var items = document.querySelectorAll('ul.results > li, .results li, .search-result, li.film-detail');
    items.forEach(function (li) {
      var a = li.querySelector('a[href*="/film/"]');
      var p = a ? filmPath(a.getAttribute('href')) : null;
      if (!p) {
        var d = li.querySelector('[data-target-link],[data-item-link],[data-film-link]');
        if (d) p = filmPath(d.getAttribute('data-target-link') || d.getAttribute('data-item-link') || d.getAttribute('data-film-link'));
      }
      add(p, li.textContent);
    });
    if (!cands.length) {
      // Plan B: cualquier enlace a una película dentro del contenido principal.
      var root = document.querySelector('#content, main, .content-wrap') || document.body;
      root.querySelectorAll('a[href*="/film/"]').forEach(function (a) {
        add(filmPath(a.getAttribute('href')), (a.closest('li') || a).textContent);
      });
    }
    if (!cands.length) return '';
    if (year) {
      for (var i = 0; i < cands.length; i++) {
        if (cands[i].text.indexOf(year) >= 0) return cands[i].path;
      }
    }
    return cands[0].path;
  }

  // ---------- Página de la película ----------
  function signature(el) {
    var cls = typeof el.className === 'string' ? el.className : (el.className && el.className.baseVal) || '';
    return [cls, el.getAttribute('href'), el.getAttribute('data-action'), el.getAttribute('title'),
      el.getAttribute('aria-label'), el.getAttribute('data-original-title'),
      clean(el.textContent).slice(0, 60)].join(' ').toLowerCase();
  }

  var REMOVE_RE = /remove[\s-]*(?:this[\s-]*film[\s-]*)?from[\s-]*(?:your[\s-]*)?watchlist|remove-watchlist|(?:in|on)[\s-]*your[\s-]*watchlist|watchlisted|(^|\s)-on(\s|$)|is-on|(^|\s)-active(\s|$)/;
  var ADD_RE = /add[\s-]*(?:this[\s-]*film[\s-]*)?to[\s-]*(?:your[\s-]*)?watchlist|add-watchlist|\bwatchlist\b/;

  function findWatchlistControls() {
    // Primero busco en el panel de acciones de la película, para no tocar
    // los pósters de "películas similares", que también tienen su botón.
    var scopes = ['#userpanel', '.actions-panel', '.film-actions', '[class*="actions-panel"]',
      '[class*="userpanel"]', 'aside', '.sidebar'];
    var root = null;
    for (var i = 0; i < scopes.length; i++) {
      var r = document.querySelector(scopes[i]);
      if (r && /watchlist/i.test(r.innerHTML)) { root = r; break; }
    }
    var wholePage = !root;
    root = root || document.body;

    var addEls = [], removeEls = [];
    root.querySelectorAll('a,button,span,li,label,div,input,[role="button"],[data-action],[aria-label],[title]').forEach(function (el) {
      var s = signature(el);
      if (s.indexOf('watchlist') < 0) return;
      var href = el.getAttribute('href') || '';
      if (/^\/[^\/]+\/watchlist\/?/.test(href)) return;             // enlace a tu perfil, no es el botón
      if (el.querySelectorAll('*').length > 40) return;             // contenedor demasiado grande
      if (wholePage && el.closest('.poster-list, [class*="poster-container"], [class*="similar"]')) return;
      if (REMOVE_RE.test(s)) removeEls.push(el);
      else if (ADD_RE.test(s)) addEls.push(el);
    });
    return {
      add: addEls.filter(visible), remove: removeEls.filter(visible),
      addAll: addEls, removeAll: removeEls
    };
  }

  function loggedOut() {
    var t = (document.body && document.body.innerText) || '';
    return /sign in to log|sign in to rate|sign in to review|create (?:an )?account to/i.test(t);
  }

  // "on" = ya está, "off" = no está, "logged_out" = sin sesión, "unknown" = no encuentro el botón
  function state() {
    var f = findWatchlistControls();
    if (f.remove.length) return 'on';
    if (f.add.length) return 'off';
    if (loggedOut()) return 'logged_out';
    // Botones que existen pero están ocultos (por ejemplo, dentro de un menú cerrado)
    if (f.removeAll.length && !f.addAll.length) return 'on';
    if (f.addAll.length && !f.removeAll.length) return 'off';
    return 'unknown';
  }

  function clickAdd() {
    var f = findWatchlistControls();
    var list = f.add.length ? f.add : f.addAll;
    if (!list.length) return 'none';
    var best = null;
    for (var i = 0; i < list.length && !best; i++) {
      if (/add-to-watchlist|add[\s-]*(?:this[\s-]*film[\s-]*)?to[\s-]*(?:your[\s-]*)?watchlist/.test(signature(list[i])) &&
          list[i].matches('a,button,input,[role="button"],[data-action]')) best = list[i];
    }
    for (var j = 0; j < list.length && !best; j++) {
      if (list[j].matches('a,button,input,[role="button"],[data-action]')) best = list[j];
    }
    best = best || list[0];
    try { best.scrollIntoView({ block: 'center' }); } catch (e) { /* no es imprescindible */ }
    best.click();
    return 'clicked';
  }

  // Resumen de lo que hay en la página, para poder ajustar el código si algo falla.
  function diagnose() {
    var out = ['URL: ' + location.href, 'Sesión cerrada: ' + loggedOut(),
      'Ancho de pantalla: ' + window.innerWidth];
    var n = 0;
    document.querySelectorAll('*').forEach(function (el) {
      if (n >= 12 || el.children.length > 8 || /^(HTML|BODY|HEADER|MAIN|SECTION|NAV)$/.test(el.tagName)) return;
      var s = signature(el);
      if (s.indexOf('watchlist') < 0) return;
      n++;
      out.push('- <' + el.tagName.toLowerCase() + '> class="' + (typeof el.className === 'string' ? el.className : '') +
        '" aria="' + (el.getAttribute('aria-label') || '') + '" title="' + (el.getAttribute('title') || '') +
        '" action="' + (el.getAttribute('data-action') || el.getAttribute('href') || '') +
        '" texto="' + clean(el.textContent).slice(0, 40) + '" visible=' + visible(el));
    });
    if (!n) {
      out.push('Ningún elemento menciona "watchlist". Clases de botones en la página:');
      var seen = {};
      document.querySelectorAll('button,[role="button"],a[class]').forEach(function (el) {
        var c = typeof el.className === 'string' ? el.className.trim() : '';
        if (c && !seen[c] && Object.keys(seen).length < 25) { seen[c] = 1; out.push('  ' + c + ' | ' + clean(el.textContent).slice(0, 30)); }
      });
    }
    return out.join('\n');
  }

  function filmTitle() {
    var h = document.querySelector('h1.headline-1, h1.filmtitle, .film-header h1, h1');
    return clean(h ? h.textContent : document.title);
  }

  window.__lbw = { pickResult: pickResult, state: state, clickAdd: clickAdd, filmTitle: filmTitle, diagnose: diagnose };
})();
