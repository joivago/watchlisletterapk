package com.jivan.lbwatchlist

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLEncoder

class MainActivity : Activity() {

    companion object {
        const val VERSION = "1.2"
    }

    private lateinit var web: WebView
    private lateinit var input: EditText
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var btnStart: Button
    private lateinit var btnNext: Button
    private lateinit var btnStop: Button

    private val handler = Handler(Looper.getMainLooper())
    private var jsLib = ""

    /** Una línea de la lista: título a buscar, año opcional o enlace directo. */
    data class Item(val raw: String, val query: String, val year: String?, val directUrl: String?)

    private enum class Phase { IDLE, SEARCH, FILM, WAIT_USER }

    private var phase = Phase.IDLE
    private val queue = mutableListOf<Item>()
    private var index = 0
    private var attempts = 0
    private var clicked = false
    private var pageToken = 0      // cada carga nueva invalida las comprobaciones antiguas
    private var pollingFor = -1

    private var added = 0
    private var already = 0
    private val unconfirmed = mutableListOf<String>()
    private val failed = mutableListOf<String>()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        web = findViewById(R.id.web)
        input = findViewById(R.id.input)
        log = findViewById(R.id.log)
        logScroll = findViewById(R.id.logScroll)
        btnStart = findViewById(R.id.btnStart)
        btnNext = findViewById(R.id.btnNext)
        btnStop = findViewById(R.id.btnStop)

        // Una sola vez tras actualizar: borro la sesión a medias que pudo dejar la v1.1.
        val prefs = getSharedPreferences("ajustes", MODE_PRIVATE)
        if (!prefs.getBoolean("limpio_v12", false)) {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            prefs.edit().putBoolean("limpio_v12", true).apply()
        }

        jsLib = assets.open("lbw.js").bufferedReader().use { it.readText() }

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        // Me identifico como el Chrome real del móvil, solo quitando la marca de "navegador dentro de app".
        // (Fingir ser un ordenador hacía que Letterboxd bloqueara el inicio de sesión.)
        web.settings.userAgentString = web.settings.userAgentString
            .replace("; wv", "")
            .replace(Regex("""Version/\d+(\.\d+)* """), "")
        web.settings.setSupportZoom(true)
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                CookieManager.getInstance().flush()   // guarda la sesión de Letterboxd
                onPageReady()
            }
        }

        btnStart.setOnClickListener { start() }
        btnNext.setOnClickListener { skipOrContinue() }
        btnStop.setOnClickListener { stop("Parado.") }
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        btnLogin.setOnClickListener {
            web.loadUrl("https://letterboxd.com/sign-in/")
        }
        // Pulsación larga: borrar la sesión y empezar de cero.
        btnLogin.setOnLongClickListener {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            web.clearCache(true)
            say("Sesión borrada. Pulsa «Mi cuenta» para volver a entrar.")
            web.loadUrl("https://letterboxd.com/")
            true
        }

        say("LB Watchlist v${VERSION}")
        say("Inicia sesión en Letterboxd aquí abajo (solo la primera vez), escribe o pega películas y pulsa «Añadir».")
        web.loadUrl("https://letterboxd.com/")
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    /** Texto recibido desde "Compartir" en otra app. */
    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        if (text.isEmpty()) return
        val current = input.text.toString().trim()
        input.setText(if (current.isEmpty()) text else "$current\n$text")
        say("Recibido: ${text.lines().first()}")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else @Suppress("DEPRECATION") super.onBackPressed()
    }

    // ---------------- Lectura de la lista ----------------

    private val bullet = Regex("""^\s*(?:[-*•·]|\d+[.)])\s+""")
    private val filmUrl = Regex("""letterboxd\.com/film/([^/\s?#]+)""", RegexOption.IGNORE_CASE)
    private val shortUrl = Regex("""https?://boxd\.it/\S+""", RegexOption.IGNORE_CASE)
    // El año solo cuenta entre paréntesis o tras coma/guion, para no romper "Blade Runner 2049".
    private val withYear = Regex("""^(.*?)\s*(?:\(((?:18|19|20)\d{2})\)|[,–-]\s*((?:18|19|20)\d{2}))\s*$""")

    private fun parse(text: String): List<Item> {
        val seen = HashSet<String>()
        val out = mutableListOf<Item>()
        for (line0 in text.lines()) {
            val line = line0.replace(bullet, "").trim()
            if (line.isEmpty() || !seen.add(line.lowercase())) continue
            val film = filmUrl.find(line)
            val short = shortUrl.find(line)
            val year = withYear.find(line)
            out += when {
                film != null -> Item(line, line, null, "https://letterboxd.com/film/${film.groupValues[1]}/")
                short != null -> Item(line, line, null, short.value)
                year != null && year.groupValues[1].isNotBlank() ->
                    Item(line, year.groupValues[1].trim(), year.groupValues[2].ifEmpty { year.groupValues[3] }, null)
                else -> Item(line, line, null, null)
            }
        }
        return out
    }

    // ---------------- Proceso ----------------

    private fun start() {
        val items = parse(input.text.toString())
        if (items.isEmpty()) {
            Toast.makeText(this, "Escribe al menos una película", Toast.LENGTH_SHORT).show()
            return
        }
        queue.clear(); queue += items
        index = 0; added = 0; already = 0
        unconfirmed.clear(); failed.clear()
        log.text = ""
        say("Empiezo con ${items.size} película(s).")
        btnStart.isEnabled = false
        btnStop.isEnabled = true
        btnNext.isEnabled = true
        btnNext.text = "Saltar"
        next()
    }

    private fun next() {
        pageToken++
        attempts = 0
        clicked = false
        if (index >= queue.size) { finishRun(); return }
        val item = queue[index]
        say("(${index + 1}/${queue.size}) ${item.raw}")
        if (item.directUrl != null) {
            phase = Phase.FILM
            web.loadUrl(item.directUrl)
        } else {
            phase = Phase.SEARCH
            web.loadUrl("https://letterboxd.com/search/films/" + URLEncoder.encode(item.query, "UTF-8") + "/")
        }
    }

    private fun advance() {
        index++
        next()
    }

    private fun onPageReady() {
        if (phase != Phase.SEARCH && phase != Phase.FILM) return
        if (pollingFor == pageToken) return   // ya estoy comprobando esta carga
        pollingFor = pageToken
        val token = pageToken
        handler.postDelayed({ poll(token) }, 900)
    }

    private fun js(call: String, cb: (String) -> Unit) {
        web.evaluateJavascript("$jsLib\n;$call") { raw ->
            val value = try { JSONTokener(raw).nextValue() as? String } catch (e: Exception) { null }
            cb(value.orEmpty())
        }
    }

    private fun poll(token: Int) {
        if (token != pageToken) return
        when (phase) {
            Phase.SEARCH -> pollSearch(token)
            Phase.FILM -> pollFilm(token)
            else -> Unit
        }
    }

    private fun retry(token: Int, delay: Long = 700) = handler.postDelayed({ poll(token) }, delay)

    private fun pollSearch(token: Int) {
        val year = queue[index].year
        val yearArg = if (year == null) "null" else JSONObject.quote(year)
        js("__lbw.pickResult($yearArg)") { path ->
            if (token != pageToken) return@js
            when {
                path.startsWith("/film/") -> {
                    phase = Phase.FILM
                    pageToken++
                    attempts = 0
                    web.loadUrl("https://letterboxd.com$path")
                }
                ++attempts < 8 -> retry(token)
                else -> {
                    say("   ✗ No la encuentro en Letterboxd.")
                    failed += queue[index].raw
                    advance()
                }
            }
        }
    }

    private fun pollFilm(token: Int) {
        if (web.url?.contains("/film/") != true) {
            if (++attempts < 15) retry(token) else pauseForUser("No ha cargado la ficha de la película.")
            return
        }
        js("__lbw.state()") { state ->
            if (token != pageToken) return@js
            when (state) {
                "on" -> titled { t ->
                    if (clicked) { added++; say("   ✓ Añadida: $t") }
                    else { already++; say("   • Ya estaba en tu watchlist: $t") }
                    handler.postDelayed({ if (token == pageToken) advance() }, 500)
                }
                "off" -> {
                    if (!clicked) {
                        js("__lbw.clickAdd()") { r ->
                            if (token != pageToken) return@js
                            clicked = r == "clicked"
                            attempts = 0
                            retry(token, 1500)
                        }
                    } else if (++attempts < 5) {
                        retry(token, 1000)
                    } else titled { t ->
                        say("   ? Pulsé el botón pero no se confirmó: $t (¿has iniciado sesión?)")
                        unconfirmed += queue[index].raw
                        advance()
                    }
                }
                "logged_out" -> stop("✗ No has iniciado sesión en Letterboxd. Pulsa «Mi cuenta», entra con tu usuario y contraseña y vuelve a pulsar «Añadir».")
                else -> if (++attempts < 15) retry(token) else {
                    pauseForUser("No encuentro el botón de Watchlist.")
                    js("__lbw.diagnose()") { report ->
                        val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clip.setPrimaryClip(ClipData.newPlainText("diagnostico", "LB Watchlist v$VERSION\n$report"))
                        say("   (He copiado un diagnóstico al portapapeles: pégaselo a Claude si esto se repite.)")
                    }
                }
            }
        }
    }

    private fun titled(cb: (String) -> Unit) = js("__lbw.filmTitle()") { cb(it.ifEmpty { queue[index].raw }) }

    /** Cuando la automatización no puede, deja la página a la vista para que lo hagas tú. */
    private fun pauseForUser(reason: String) {
        phase = Phase.WAIT_USER
        pageToken++
        say("   ⏸ $reason Añádela tú en la página de abajo y pulsa «Siguiente» (o «Siguiente» para saltarla).")
        btnNext.text = "Siguiente"
    }

    private fun skipOrContinue() {
        if (phase == Phase.IDLE) return
        if (phase != Phase.WAIT_USER) {
            say("   – Saltada.")
            failed += queue[index].raw
        } else {
            say("   → Continúo.")
        }
        btnNext.text = "Saltar"
        advance()
    }

    private fun finishRun() {
        phase = Phase.IDLE
        btnStart.isEnabled = true
        btnStop.isEnabled = false
        btnNext.isEnabled = false
        btnNext.text = "Siguiente"
        say("Terminado. Añadidas: $added · Ya estaban: $already · Sin confirmar: ${unconfirmed.size} · No encontradas o saltadas: ${failed.size}")
        // Dejo en la caja solo lo que no salió bien, para corregirlo y reintentar.
        val notDone = if (index < queue.size) queue.subList(index, queue.size).map { it.raw } else emptyList()
        val pending = unconfirmed + failed + notDone
        queue.clear()
        input.setText(pending.joinToString("\n"))
        if (pending.isNotEmpty()) say("He dejado arriba las que fallaron: corrígelas (por ejemplo, añadiendo el año) y vuelve a pulsar «Añadir».")
    }

    private fun stop(msg: String) {
        pageToken++
        say(msg)
        finishRun()
    }

    private fun say(msg: String) {
        log.append(if (log.text.isEmpty()) msg else "\n$msg")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }
}
